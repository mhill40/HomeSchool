var canvas = document.querySelector('canvas');
var c = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

c.fillStyle = "black";
c.fillRect(100, 100, 100, 100);
c.fillStyle = "green";
c.fillRect(400, 100, 100, 100);
c.fillStyle = "blue";
c.fillRect(300, 100, 100, 100);
c.fillStyle = "yellow";
c.fillRect(200, 50, 75, 350);

// Here is a circle. it spawns in a random spot. we use the window dimensions as thats the only ones that are defined atm.  

c.beginPath();
var x = Math.random() * window.innerWidth;
    var y = Math.random() * window.innerHeight;
    c.arc(x, y, 30, 0, Math.PI * 2, false);
    c.strokeStyle = 'white';
    
c.stroke();

console.log(canvas);

//I could paste it numerous times, each time changing the coordinates for a different circle position. here i will automate it with a for loop //

for (var i = 0; i < 100; i++) { 
    var x = Math.random() * window.innerWidth;
    var y = Math.random() * window.innerHeight;
    c.beginPath();
    c.arc(x, y, 30, 0, Math.PI * 2, false);
    c.strokeStyle = 'blue';
    
 c.stroke();
}